// Copyright (c) 2021, Youssef Restom and contributors
// For license information, please see license.txt

frappe.ui.form.on('Mpesa C2B Register URL', {
	// refresh: function(frm) {

	// }
});
