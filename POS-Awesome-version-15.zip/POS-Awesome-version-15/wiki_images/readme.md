This Folder contains images for the Wiki
